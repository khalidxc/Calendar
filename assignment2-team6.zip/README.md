# Calendar
Complete web project written in Flask.
